public class Casher {
    private double  totalPrice;
    private int count;
    private double amount;
    private int sales;
    private double rem;
    private double of;
    public void addItem(double price)
    {
        this.totalPrice+=price;
        this.count++;
    }
    public void removeItem(double price)
    {
        this.count--;
       this. totalPrice-=price;
        
    }
    public int getItemCount()
    {
        return this.count;
    }
    public double getTotalPrice()
    {
        return this.totalPrice;
    }
    public void setTotalPrice(double x)
    {
        this.totalPrice=x;
    }
    public void setOf(double x)
    {
         this.of=x;
    }
    public double getOf()
    {
        return this.of;
    }
    public void off()
    {
       
       this. totalPrice=this.totalPrice*this.of;
    }
    public int getSales()
    {
        return this.sales;
    }
    public double getAmount()
    {
        return this.amount;
    }
    
    public void clear()
    {
        this.totalPrice=this.amount=0.0;
        count=0;
    }
    public double calc(double amt)
    {
        this.amount=amt;
        double s=amt-this.totalPrice;
        if(s>=0)
        {this.sales++;
        this.rem=s;
        return s;
        }
        else
            return 0;
    }
    public double getR()
    {
        return this.rem;
    }
    public void payByVisa(int visaId)
    {
    this.rem=0;
    this.amount=this.totalPrice;
    this.sales++;
}
}