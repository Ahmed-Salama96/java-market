
public class Worker extends Casher{
   private double salary;
   private int id;
   public void resetSal()
   {
       salary=3000;
   }
  public double removeFromSal()
  {
      return salary-super.getTotalPrice();
  }
  public double offf()
  {
      return super.getTotalPrice()* 0.25;
  }
  
}